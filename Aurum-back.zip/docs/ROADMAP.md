# Aurum – Roadmap

## MVP Core Bancario
(Ver MVP_CORE.md)

## MVP-2 – Seguridad y UX
- Refresh tokens
- MFA
- Recupero de contraseña

## MVP-3 – Operación
- Notificaciones
- Admin panel
- Auditoría

## MVP-4 – Escalabilidad
- Async
- Cache
- Eventos
