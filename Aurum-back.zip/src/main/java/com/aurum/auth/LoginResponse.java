package com.aurum.auth;

public record LoginResponse(String accessToken, String tokenType) {}
