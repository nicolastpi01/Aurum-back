package com.aurum.auth.dto;

public record LoginResponse(String accessToken, String tokenType) {}
