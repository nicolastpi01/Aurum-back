package com.aurum.auth;

public class InvalidCredentialsException extends RuntimeException {}