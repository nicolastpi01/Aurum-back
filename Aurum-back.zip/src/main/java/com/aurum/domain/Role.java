package com.aurum.domain;

public enum Role {
    ADMIN,
    USER
}
