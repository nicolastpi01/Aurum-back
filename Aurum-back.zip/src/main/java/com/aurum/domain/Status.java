package com.aurum.domain;

public enum Status {
    ACTIVE, BLOCKED
}
