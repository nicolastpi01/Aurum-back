package com.aurum.users.domain;

public enum Role {
    ADMIN,
    USER
}
