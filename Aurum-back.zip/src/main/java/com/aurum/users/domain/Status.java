package com.aurum.users.domain;

public enum Status {
    ACTIVE, BLOCKED
}
