package com.aurum.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AurumApplicationTests {

	@Test
	void contextLoads() {
	}

}
